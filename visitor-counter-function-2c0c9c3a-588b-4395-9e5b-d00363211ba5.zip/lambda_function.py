# lambda_function.py
import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('visitor-counter')



def lambda_handler(event, context):
    # Common CORS headers
    cors_headers = {
        'Access-Control-Allow-Origin': '*',  # change '*' to your domain in production
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
        'Cache-Control': 'no-cache'
    }

    # 1) Handle preflight OPTIONS request
    if event.get('httpMethod', '') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': ''
        }

    # 2) Handle POST request to increment visitor count
    try:
        response = table.update_item(
            Key={'id': 'visits'},
            UpdateExpression='SET #count = #count + :inc',
            ExpressionAttributeNames={'#count': 'count'},
            ExpressionAttributeValues={':inc': 1},
            ReturnValues='UPDATED_NEW'
        )
        count = response['Attributes']['count']

        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({'count': int(count)})
        }

    except Exception as e:
        print(f"Error updating count: {e}")  # logs to CloudWatch
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': str(e), 'count': 0})
        }
